# -*- coding:utf-8 -*-

import json
import urllib3
from json import loads
import requests
import logging
"""
Modole de requissões APi zabbix de forma simplificada
"""

class ZabbixApi:
    def __init__(self, urlZabbix, user="", password=""):
        """
        Definições inicial da classe
        """
        logging.captureWarnings(True)
        self.urlApi = self.__checkUrl(urlZabbix)
        self.headers = {"Content-Type": "application/json"}
        self.idResquest = 0
        self.objectRequest = {
            "jsonrpc": "2.0", 
            "method": 
            "apiinfo.version", 
            "params": {}, 
            "auth": None, 
            "id": self.idResquest
        }
        print(self.apiRequest())
        self.loginZabbix(user, password)

    def __checkUrl(self, urlZabbix):
        l = len(urlZabbix) - 1
        if(urlZabbix[l]=="/"):
            return urlZabbix+"api_jsonrpc.php"
        return urlZabbix+"/api_jsonrpc.php"

    def loginZabbix(self, user, password):
        """Realizar Login"""
        data = self.apiRequest("user.login", {"user": user, "password": password})
        #if(self.checkLogin(data)):
        self.objectRequest["auth"] = data
    
    def logoutZabbix(self,):
        """Realizar Logout"""
        if(self.apiRequest("user.logout")):
            self.objectRequest["auth"] = None
            return True
        return False

    def checkLogin(self,sessionid):
        """Vericação de Login"""
        method= "user.checkAuthentication"
        params= {"sessionid":sessionid}
        self.objectRequest["auth"] = None
        check = self.apiRequest(method,params)
        if(check.get("code")):
            return False
        self.objectRequest["auth"] = sessionid
        return True

    def __printError(self,error):
        print("Erro no Request!\nCode: {} \nMensage: {} \nData: {}".format(error.get("code"),error.get("message"),error.get("data")))
    def apiRequest(self, method="apiinfo.version", params={}):
        """Metodo para realiza request na API"""
        try:
            self.objectRequest["params"] = params
            self.objectRequest["method"] = method
            self.idResquest = self.idResquest + 1
            request = requests.post(self.urlApi, headers=self.headers, json=self.objectRequest, verify=False)
            self.objectRequest["params"] = {}
            self.objectRequest["id"] = self.idResquest
            if(request.status_code != 200):
                raise urllib3.exceptions.HTTPError("Status code: {}".format(request.status_code))
            data = loads(request.text)
            if(data.get("error")):
                self.__printError(data.get("error"))
                return data.get("error")
            return data.get("result")
        except requests.exceptions.ConnectionError as e:
            print("Falha na conexão! Favor verificar URL.")
            print(e)
        except requests.exceptions.RequestException as e:
            print("Erro na requisição!")
            print(e)   
        except urllib3.exceptions.HTTPError as e:
            print("Erro na requisição!")
            print(e)   
        except json.JSONDecodeError as e:
            print("Erro nos dados recebidos!")
            print(e)
        except Exception as e:
            print("Erro!")
            print(e)
