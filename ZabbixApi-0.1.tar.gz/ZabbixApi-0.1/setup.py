from setuptools import setup


setup(name='ZabbixApi',
      version='0.1',
      description='Acesso ao api do zabbix com python',
      url='https://gitlab.poupex.com.br/poupex/infra/eqcop/zabbix/ZabbixApi',
      author='Amilson Gaspar de Jesus',
      author_email='amilson.jesus@poupex.com.br',
      packages=['ZabbixApi'],
      zip_safe=False)